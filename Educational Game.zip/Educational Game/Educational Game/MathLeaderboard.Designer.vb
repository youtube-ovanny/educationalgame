﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MathLeaderboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        RichTextBox1 = New RichTextBox()
        Button3 = New Button()
        Button2 = New Button()
        Button1 = New Button()
        Label1 = New Label()
        SuspendLayout()
        ' 
        ' RichTextBox1
        ' 
        RichTextBox1.Location = New Point(238, 41)
        RichTextBox1.Name = "RichTextBox1"
        RichTextBox1.Size = New Size(212, 278)
        RichTextBox1.TabIndex = 9
        RichTextBox1.Text = ""
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.MediumSlateBlue
        Button3.Font = New Font("Yu Gothic", 12F)
        Button3.Location = New Point(34, 259)
        Button3.Name = "Button3"
        Button3.Size = New Size(143, 60)
        Button3.TabIndex = 8
        Button3.Text = "RETURN"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.MediumSlateBlue
        Button2.Font = New Font("Yu Gothic", 12F)
        Button2.Location = New Point(34, 159)
        Button2.Name = "Button2"
        Button2.Size = New Size(143, 60)
        Button2.TabIndex = 7
        Button2.Text = "CLEAR INFO"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.MediumSlateBlue
        Button1.Font = New Font("Yu Gothic", 12F)
        Button1.Location = New Point(34, 60)
        Button1.Name = "Button1"
        Button1.Size = New Size(143, 60)
        Button1.TabIndex = 6
        Button1.Text = "VIEW LEADERBOARD"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.White
        Label1.Location = New Point(145, 7)
        Label1.Name = "Label1"
        Label1.Size = New Size(210, 31)
        Label1.TabIndex = 10
        Label1.Text = "Math High Scores"
        ' 
        ' MathLeaderboard
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.DarkSlateBlue
        ClientSize = New Size(484, 361)
        Controls.Add(Label1)
        Controls.Add(RichTextBox1)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Name = "MathLeaderboard"
        Text = "MathLeaderboard"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
End Class
