﻿Imports System.IO

Public Class mathGame

    Dim num1, num2, answer As Integer
    Dim operatorType As Char
    Dim score As Integer = 0
    Dim path As String = "C:\Users\s297635\source\repos\Educational Game\Educational Game"
    Dim filename As String = System.IO.Path.Combine(path, "MathHighScores")

    Private Sub mathGame_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GenerateQuestion()
    End Sub

    Private Sub GenerateQuestion()
        Dim rand As New Random()
        num1 = rand.Next(1, 11) ' Generate a random number between 1 and 10
        num2 = rand.Next(1, 11) ' Generate another random number between 1 and 10

        ' Ensure the larger number is on the left side of the equation
        If num1 < num2 Then
            Dim temp As Integer = num1
            num1 = num2
            num2 = temp
        End If

        ' Generate a random operator
        Dim operators() As Char = {"+", "-", "*"}
        Dim randOperator As Integer = rand.Next(0, operators.Length)
        operatorType = operators(randOperator)

        ' Display the question
        Label2.Text = num1.ToString() & " " & operatorType & " " & num2.ToString() & " = ?"

        ' Calculate the correct answer
        Select Case operatorType
            Case "+"
                answer = num1 + num2
            Case "-"
                answer = num1 - num2
            Case "*"
                answer = num1 * num2
        End Select

        ' Generate random wrong answers for multiple choice
        Dim choices() As Integer = {answer}
        While choices.Length < 4
            Dim randChoice As Integer = rand.Next(1, 101)
            If Not choices.Contains(randChoice) Then
                Array.Resize(choices, choices.Length + 1)
                choices(choices.Length - 1) = randChoice
            End If
        End While

        ' Shuffle choices array
        For i As Integer = 0 To choices.Length - 1
            Dim temp As Integer = choices(i)
            Dim index As Integer = rand.Next(i, choices.Length)
            choices(i) = choices(index)
            choices(index) = temp
        Next

        ' Display multiple choice answers on buttons
        Button1.Text = choices(0).ToString()
        Button2.Text = choices(1).ToString()
        Button3.Text = choices(2).ToString()
        Button4.Text = choices(3).ToString()
    End Sub

    Private Sub CheckAnswer(userAnswer As Integer)
        If userAnswer = answer Then
            score += 1
            Label1.Text = "Score: " & score.ToString()
        Else
            Dim playerName As String = InputBox("Enter your name for the high score:", "High Score")
            MessageBox.Show("Thank you, " & playerName & ", for playing!", "Thank You")
            Dim path As String = "C:\Users\s297635\source\repos\Educational Game\Educational Game"
            Dim filename As String = System.IO.Path.Combine(path, "MathHighScores.txt")

            ' Read existing scores from the file
            Dim scores As New List(Of KeyValuePair(Of String, Integer))()
            If File.Exists(filename) Then
                Using reader As New StreamReader(filename)
                    Dim line As String
                    While Not reader.EndOfStream
                        line = reader.ReadLine()
                        Dim parts() As String = line.Split(","c)
                        If parts.Length = 2 Then
                            Dim name As String = parts(0)
                            Dim scoreValue As Integer
                            If Integer.TryParse(parts(1), scoreValue) Then
                                scores.Add(New KeyValuePair(Of String, Integer)(name, scoreValue))
                            End If
                        End If
                    End While
                End Using
            End If

            ' Add the new score to the list
            scores.Add(New KeyValuePair(Of String, Integer)(playerName, score))

            ' Sort the scores in descending order
            scores = scores.OrderByDescending(Function(x) x.Value).ToList()

            ' Save only the top 5 scores back to the file
            Using writer As New StreamWriter(filename, False)
                For i As Integer = 0 To Math.Min(4, scores.Count - 1)
                    writer.WriteLine("----------------------")
                    writer.WriteLine("Name: " & scores(i).Key)
                    writer.WriteLine("Score: " & scores(i).Value)
                Next
            End Using

            score = 0 ' Reset score after incorrect answer
            Label1.Text = "Score: " & score.ToString()
            Me.Hide()
            Main_menu.Show()
        End If
        GenerateQuestion() ' Generate a new question after answering
    End Sub





    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        CheckAnswer(Integer.Parse(Button1.Text))
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        CheckAnswer(Integer.Parse(Button2.Text))
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        CheckAnswer(Integer.Parse(Button3.Text))
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        CheckAnswer(Integer.Parse(Button4.Text))
    End Sub
End Class
