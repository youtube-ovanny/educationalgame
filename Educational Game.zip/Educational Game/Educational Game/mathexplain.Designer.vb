﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mathexplain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Button1 = New Button()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Button2 = New Button()
        SuspendLayout()
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(63, 223)
        Button1.Name = "Button1"
        Button1.Size = New Size(163, 77)
        Button1.TabIndex = 0
        Button1.Text = "PLAY"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(185, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(127, 27)
        Label1.TabIndex = 1
        Label1.Text = "How to play"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Yu Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(19, 51)
        Label2.Name = "Label2"
        Label2.Size = New Size(446, 50)
        Label2.TabIndex = 2
        Label2.Text = "There will be a question at the top of your screen" & vbCrLf & "               and 4 multiple choice answers" & vbCrLf
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Yu Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(19, 112)
        Label3.Name = "Label3"
        Label3.Size = New Size(453, 50)
        Label3.TabIndex = 3
        Label3.Text = "Choose the right answer for your score to go up" & vbCrLf & "If you choose the wrong answer the game will end" & vbCrLf
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(271, 223)
        Button2.Name = "Button2"
        Button2.Size = New Size(163, 77)
        Button2.TabIndex = 4
        Button2.Text = "BACK"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' mathexplain
        ' 
        AutoScaleDimensions = New SizeF(12F, 27F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.MediumSlateBlue
        ClientSize = New Size(484, 361)
        Controls.Add(Button2)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(Button1)
        Font = New Font("Yu Gothic", 15.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Margin = New Padding(5)
        Name = "mathexplain"
        Text = "mathexplain"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button2 As Button
End Class
