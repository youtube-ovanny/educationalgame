﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main_menu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label3 = New Label()
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        SuspendLayout()
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(99, 23)
        Label3.Name = "Label3"
        Label3.Size = New Size(337, 31)
        Label3.TabIndex = 2
        Label3.Text = "What would you like to learn?" & vbCrLf
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.MediumSlateBlue
        Button1.Font = New Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(96, 130)
        Button1.Name = "Button1"
        Button1.Size = New Size(178, 79)
        Button1.TabIndex = 3
        Button1.Text = "MATH"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.MediumSlateBlue
        Button2.Font = New Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.Location = New Point(280, 130)
        Button2.Name = "Button2"
        Button2.Size = New Size(178, 79)
        Button2.TabIndex = 4
        Button2.Text = "ENGLISH"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.MediumSlateBlue
        Button3.Font = New Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button3.Location = New Point(154, 215)
        Button3.Name = "Button3"
        Button3.Size = New Size(237, 70)
        Button3.TabIndex = 5
        Button3.Text = "BACK"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Main_menu
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.MediumSlateBlue
        ClientSize = New Size(534, 361)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(Label3)
        Name = "Main_menu"
        Text = "Main_menu"
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
End Class
