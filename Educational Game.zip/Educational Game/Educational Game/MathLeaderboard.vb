﻿Public Class MathLeaderboard
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim path As String = "C:\Users\s297635\source\repos\Educational Game\Educational Game"
        Dim filename As String = System.IO.Path.Combine(path, "MathHighScores.txt")
        Dim filereader As String


        ' Read the content of the file
        filename = My.Computer.FileSystem.ReadAllText(filename)

        ' Display the content in the RichTextBox
        RichTextBox1.Text = filename
        filereader = My.Computer.FileSystem.ReadAllText("C:\Users\s297635\source\repos\Educational Game\Educational Game\MathHighScores.txt")
        RichTextBox1.Text = filename
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        RichTextBox1.Text = Nothing
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Hide()
        leaderboards.Show()
    End Sub
End Class
' "